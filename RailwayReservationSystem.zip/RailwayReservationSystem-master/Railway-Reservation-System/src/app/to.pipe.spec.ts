import { TOPipe } from './to.pipe';

describe('TOPipe', () => {
  it('create an instance', () => {
    const pipe = new TOPipe();
    expect(pipe).toBeTruthy();
  });
});
