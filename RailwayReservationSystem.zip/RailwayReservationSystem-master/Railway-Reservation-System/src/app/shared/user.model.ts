import { TemplateLiteral } from "@angular/compiler";

export class User {
    PassengerId: number;
    FirstName: string;
    LastName: string;
    EmailId: string;
    Password: string;
    Gender: string;
    Age: string;
    MobileNumber: string ;
    
    
    

}

