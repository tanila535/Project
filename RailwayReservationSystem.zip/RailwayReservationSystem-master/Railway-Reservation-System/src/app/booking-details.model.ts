export class BookingDetails {
    TrainId :number;
    TravellingFrom:string;
    TravellingTo:string;
    DepartureDate:string;
    ReturningDate:string;
    Adults:number;
    Children:number;
}