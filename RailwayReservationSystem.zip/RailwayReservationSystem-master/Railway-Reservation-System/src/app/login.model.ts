export class LoginModel{
    //Id : number;
    EmailId : string;
    Password : string;
}